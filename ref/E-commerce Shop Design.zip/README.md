
  # E-commerce Shop Design

  This is a code bundle for E-commerce Shop Design. The original project is available at https://www.figma.com/design/VxRX1muYhrb9mAfyH1gMFi/E-commerce-Shop-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  